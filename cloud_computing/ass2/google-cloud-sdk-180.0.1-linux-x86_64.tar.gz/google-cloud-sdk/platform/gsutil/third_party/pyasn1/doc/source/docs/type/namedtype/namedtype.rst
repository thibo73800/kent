
.. |NamedType| replace:: NamedType

|NamedType|
-----------

.. autoclass:: pyasn1.type.namedtype.NamedType
   :members:

   .. note::

        The |NamedType| class models a mandatory field of a constructed ASN.1 type.
