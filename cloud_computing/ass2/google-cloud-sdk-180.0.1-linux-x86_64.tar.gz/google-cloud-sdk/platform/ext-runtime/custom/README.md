
Custom Runtime Definition
=========================

This is the runtime definition for GAE "custom" runtimes.  Its only job is to
generate an app.yaml when it sees a Dockerfile present.

